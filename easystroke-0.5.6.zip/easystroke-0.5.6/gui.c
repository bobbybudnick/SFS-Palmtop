const char *gui_buffer = "\
<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<interface>\n\
<requires lib=\"gtk+\" version=\"2.16\"/>\n\
<!-- interface-naming-policy toplevel-contextual -->\n\
<object class=\"GtkAboutDialog\" id=\"aboutdialog\">\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"border_width\">5</property>\n\
<property name=\"window_position\">center</property>\n\
<property name=\"type_hint\">normal</property>\n\
<property name=\"copyright\">Copyright © 2008-2009 Thomas Jaeger.</property>\n\
<property name=\"website\">http://easystroke.sourceforge.net</property>\n\
<property name=\"website_label\">http://easystroke.sourceforge.net</property>\n\
<property name=\"authors\">Thomas Jaeger &lt;ThJaeger@gmail.com&gt;</property>\n\
<property name=\"translator_credits\">El Libre (Catalan)\n\
Jordis (Catalan)\n\
John Luk (Chinese - Simplified)\n\
Kenny Wang (Chinese - Simplified)\n\
于 (Chinese - Traditional)\n\
Jakub Žáček (Czech)\n\
Sauli Pelkonen (Finnish)\n\
Loïc Guégant (French)\n\
Antoine Del Piccolo (French)\n\
Γουργιώτης Γιώργος (Greek)\n\
Yaron (Hebrew)\n\
Péter Trombitás (Hungarian)\n\
Massimiliano La Gala (Italian)\n\
Jiro Kawada (Japanese)\n\
Jincreator (Korean)\n\
Tomasz Kołodziejski (Polish)\n\
Claque (Russian)\n\
Marcos (Spanish)\n\
Paco Molinero (Spanish)\n\
Sweettuxy (Spanish)\n\
Jesus Vera (Spanish)\n\
Martín V. (Spanish)\n\
Van Diep Duong (Vietnamese)</property>\n\
<child internal-child=\"vbox\">\n\
<object class=\"GtkVBox\" id=\"dialog-vbox4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">2</property>\n\
<child internal-child=\"action_area\">\n\
<object class=\"GtkHButtonBox\" id=\"dialog-action_area4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"layout_style\">end</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<placeholder/>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
<object class=\"GtkAdjustment\" id=\"adjustment_final_timeout\">\n\
<property name=\"upper\">2500</property>\n\
<property name=\"step_increment\">5</property>\n\
<property name=\"page_increment\">20</property>\n\
</object>\n\
<object class=\"GtkAdjustment\" id=\"adjustment_init_timeout\">\n\
<property name=\"upper\">2500</property>\n\
<property name=\"step_increment\">5</property>\n\
<property name=\"page_increment\">20</property>\n\
</object>\n\
<object class=\"GtkAdjustment\" id=\"adjustment_pressure_threshold\">\n\
<property name=\"upper\">255</property>\n\
<property name=\"step_increment\">1</property>\n\
<property name=\"page_increment\">10</property>\n\
</object>\n\
<object class=\"GtkAdjustment\" id=\"adjustment_scroll_speed\">\n\
<property name=\"upper\">10</property>\n\
<property name=\"step_increment\">0.20000000000000001</property>\n\
<property name=\"page_increment\">1</property>\n\
</object>\n\
<object class=\"GtkAdjustment\" id=\"adjustment_trace_width\">\n\
<property name=\"upper\">20</property>\n\
<property name=\"step_increment\">1</property>\n\
<property name=\"page_increment\">10</property>\n\
</object>\n\
<object class=\"GtkMessageDialog\" id=\"dialog_delete\">\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"border_width\">5</property>\n\
<property name=\"type_hint\">normal</property>\n\
<property name=\"skip_taskbar_hint\">True</property>\n\
<property name=\"transient_for\">main</property>\n\
<property name=\"message_type\">warning</property>\n\
<property name=\"buttons\">cancel</property>\n\
<child internal-child=\"vbox\">\n\
<object class=\"GtkVBox\" id=\"dialog-vbox8\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">2</property>\n\
<child internal-child=\"action_area\">\n\
<object class=\"GtkHButtonBox\" id=\"dialog-action_area8\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"layout_style\">end</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_delete_delete\">\n\
<property name=\"label\">gtk-delete</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
<action-widgets>\n\
<action-widget response=\"1\">button_delete_delete</action-widget>\n\
</action-widgets>\n\
</object>\n\
<object class=\"GtkMessageDialog\" id=\"dialog_icon\">\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"border_width\">5</property>\n\
<property name=\"type_hint\">normal</property>\n\
<property name=\"skip_taskbar_hint\">True</property>\n\
<property name=\"transient_for\">main</property>\n\
<property name=\"buttons\">ok</property>\n\
<child internal-child=\"vbox\">\n\
<object class=\"GtkVBox\" id=\"dialog-vbox6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">2</property>\n\
<child internal-child=\"action_area\">\n\
<object class=\"GtkHButtonBox\" id=\"dialog-action_area6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"layout_style\">end</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
<object class=\"GtkMessageDialog\" id=\"dialog_record\">\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"border_width\">5</property>\n\
<property name=\"type_hint\">normal</property>\n\
<property name=\"skip_taskbar_hint\">True</property>\n\
<property name=\"transient_for\">main</property>\n\
<child internal-child=\"vbox\">\n\
<object class=\"GtkVBox\" id=\"dialog-vbox10\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">2</property>\n\
<child internal-child=\"action_area\">\n\
<object class=\"GtkHButtonBox\" id=\"dialog-action_area10\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"layout_style\">end</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_record_cancel\">\n\
<property name=\"label\">gtk-cancel</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_record_delete\">\n\
<property name=\"label\" translatable=\"yes\">_Delete Current</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image6</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
<action-widgets>\n\
<action-widget response=\"-1\">button_record_cancel</action-widget>\n\
<action-widget response=\"1\">button_record_delete</action-widget>\n\
</action-widgets>\n\
</object>\n\
<object class=\"GtkMessageDialog\" id=\"dialog_select\">\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"border_width\">5</property>\n\
<property name=\"type_hint\">normal</property>\n\
<property name=\"skip_taskbar_hint\">True</property>\n\
<property name=\"transient_for\">main</property>\n\
<child internal-child=\"vbox\">\n\
<object class=\"GtkVBox\" id=\"dialog-vbox9\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child internal-child=\"action_area\">\n\
<object class=\"GtkHButtonBox\" id=\"dialog-action_area9\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"layout_style\">end</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"select_cancel\">\n\
<property name=\"label\">gtk-cancel</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"select_ok\">\n\
<property name=\"label\">gtk-ok</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"select_default\">\n\
<property name=\"label\" translatable=\"yes\">_Default</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image5</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
<property name=\"secondary\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox_button_timeout\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"homogeneous\">True</property>\n\
<child>\n\
<object class=\"GtkRadioButton\" id=\"radio_timeout_default\">\n\
<property name=\"label\" translatable=\"yes\">Timeout</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"active\">True</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkRadioButton\" id=\"radio_instant\">\n\
<property name=\"label\" translatable=\"yes\">Instant Gestures</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"active\">True</property>\n\
<property name=\"draw_indicator\">True</property>\n\
<property name=\"group\">radio_timeout_default</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkRadioButton\" id=\"radio_click_hold\">\n\
<property name=\"label\" translatable=\"yes\">Click &amp; Hold</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"active\">True</property>\n\
<property name=\"draw_indicator\">True</property>\n\
<property name=\"group\">radio_timeout_default</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkTable\" id=\"table2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"n_rows\">2</property>\n\
<property name=\"n_columns\">3</property>\n\
<property name=\"column_spacing\">6</property>\n\
<property name=\"row_spacing\">6</property>\n\
<property name=\"homogeneous\">True</property>\n\
<child>\n\
<object class=\"GtkToggleButton\" id=\"toggle_control\">\n\
<property name=\"label\" translatable=\"yes\">_Control</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"top_attach\">1</property>\n\
<property name=\"bottom_attach\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkToggleButton\" id=\"toggle_shift\">\n\
<property name=\"label\" translatable=\"yes\">_Shift</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
</child>\n\
<child>\n\
<object class=\"GtkToggleButton\" id=\"toggle_alt\">\n\
<property name=\"label\" translatable=\"yes\">_Alt</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"left_attach\">1</property>\n\
<property name=\"right_attach\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkToggleButton\" id=\"toggle_super\">\n\
<property name=\"label\" translatable=\"yes\">S_uper</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"left_attach\">1</property>\n\
<property name=\"right_attach\">2</property>\n\
<property name=\"top_attach\">1</property>\n\
<property name=\"bottom_attach\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkToggleButton\" id=\"toggle_any\">\n\
<property name=\"label\" translatable=\"yes\">An_y Modifier</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"left_attach\">2</property>\n\
<property name=\"right_attach\">3</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkEventBox\" id=\"box_button\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<child>\n\
<placeholder/>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"left_attach\">2</property>\n\
<property name=\"right_attach\">3</property>\n\
<property name=\"top_attach\">1</property>\n\
<property name=\"bottom_attach\">2</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label18\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Alternatively, you may select button and modifiers below.</property>\n\
<property name=\"wrap\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkEventBox\" id=\"eventbox\">\n\
<property name=\"height_request\">200</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_BUTTON_PRESS_MASK</property>\n\
<child>\n\
<placeholder/>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">4</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
<action-widgets>\n\
<action-widget response=\"-1\">select_cancel</action-widget>\n\
<action-widget response=\"1\">select_ok</action-widget>\n\
<action-widget response=\"2\">select_default</action-widget>\n\
</action-widgets>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-media-record</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image10\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-add</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image11\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-clear</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-add</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-remove</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-add</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-clear</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-delete</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image7\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-remove</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image8\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-add</property>\n\
</object>\n\
<object class=\"GtkImage\" id=\"image9\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"stock\">gtk-remove</property>\n\
</object>\n\
<object class=\"GtkWindow\" id=\"main\">\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"window_position\">center</property>\n\
<property name=\"default_width\">800</property>\n\
<property name=\"default_height\">600</property>\n\
<child>\n\
<object class=\"GtkNotebook\" id=\"notebook1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"border_width\">6</property>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"border_width\">6</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkVPaned\" id=\"vpaned_apps\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<child>\n\
<object class=\"GtkExpander\" id=\"expander_apps\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<child>\n\
<object class=\"GtkTable\" id=\"table1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"n_rows\">2</property>\n\
<property name=\"n_columns\">2</property>\n\
<property name=\"column_spacing\">6</property>\n\
<property name=\"row_spacing\">6</property>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<object class=\"GtkTreeView\" id=\"treeview_apps\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_show_deleted\">\n\
<property name=\"label\" translatable=\"yes\">Show deleted rows</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"top_attach\">1</property>\n\
<property name=\"bottom_attach\">2</property>\n\
<property name=\"y_options\">GTK_FILL</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkVButtonBox\" id=\"vbuttonbox1\">\n\
<property name=\"height_request\">130</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<property name=\"layout_style\">start</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_add_app\">\n\
<property name=\"label\" translatable=\"yes\">Add Application</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image8</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_remove_app\">\n\
<property name=\"label\" translatable=\"yes\">Remove Application/Group</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image9</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_add_group\">\n\
<property name=\"label\" translatable=\"yes\">Add Group</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image10</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">2</property>\n\
<property name=\"secondary\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"left_attach\">1</property>\n\
<property name=\"right_attach\">2</property>\n\
<property name=\"x_options\"></property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_reset_actions\">\n\
<property name=\"label\" translatable=\"yes\">Reset Action(s)</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image11</property>\n\
</object>\n\
<packing>\n\
<property name=\"left_attach\">1</property>\n\
<property name=\"right_attach\">2</property>\n\
<property name=\"top_attach\">1</property>\n\
<property name=\"bottom_attach\">2</property>\n\
<property name=\"x_options\">GTK_FILL</property>\n\
<property name=\"y_options\"></property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label20\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Applications</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"resize\">False</property>\n\
<property name=\"shrink\">False</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow_actions\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<placeholder/>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"resize\">True</property>\n\
<property name=\"shrink\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHButtonBox\" id=\"hbuttonbox1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"spacing\">12</property>\n\
<property name=\"layout_style\">start</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_record\">\n\
<property name=\"label\" translatable=\"yes\">_Record Stroke</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image1</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_add_action\">\n\
<property name=\"label\" translatable=\"yes\">_Add Action</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image2</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_delete_action\">\n\
<property name=\"label\" translatable=\"yes\">_Delete Action(s)</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image3</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_hide1\">\n\
<property name=\"label\" translatable=\"yes\">_Hide</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">3</property>\n\
<property name=\"secondary\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"tab\">\n\
<object class=\"GtkLabel\" id=\"label1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">Actions</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"tab_fill\">False</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"border_width\">6</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkFrame\" id=\"frame_button\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label_xalign\">0</property>\n\
<property name=\"shadow_type\">none</property>\n\
<child>\n\
<object class=\"GtkAlignment\" id=\"alignment2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"top_padding\">4</property>\n\
<property name=\"bottom_padding\">4</property>\n\
<property name=\"left_padding\">12</property>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_button\">\n\
<property name=\"label\" translatable=\"yes\">_Gesture Button</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label_button\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkExpander\" id=\"expander1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkVButtonBox\" id=\"vbuttonbox2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_add_extra\">\n\
<property name=\"label\">gtk-add</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_edit_extra\">\n\
<property name=\"label\">gtk-edit</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_remove_extra\">\n\
<property name=\"label\">gtk-remove</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_stock\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow7\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<object class=\"GtkTreeView\" id=\"treeview_extra\">\n\
<property name=\"height_request\">120</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<child internal-child=\"selection\">\n\
<object class=\"GtkTreeSelection\" id=\"treeview-selection2\"/>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">5</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label11\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Additional Buttons</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox_timeout_profile\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label19\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Timeout profile</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkEventBox\" id=\"box_timeout\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<child>\n\
<placeholder/>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox_timeout\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label15\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Initial Timeout (ms)</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkSpinButton\" id=\"spin_init_timeout\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"adjustment\">adjustment_init_timeout</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label17\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">     Timeout (ms)</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkSpinButton\" id=\"spin_final_timeout\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"adjustment\">adjustment_final_timeout</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">&lt;b&gt;Behavior&lt;/b&gt;</property>\n\
<property name=\"use_markup\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkFrame\" id=\"frame_trace\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label_xalign\">0</property>\n\
<property name=\"shadow_type\">none</property>\n\
<child>\n\
<object class=\"GtkAlignment\" id=\"alignment3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"xalign\">0</property>\n\
<property name=\"xscale\">0</property>\n\
<property name=\"top_padding\">4</property>\n\
<property name=\"bottom_padding\">4</property>\n\
<property name=\"left_padding\">12</property>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox_trace\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label13\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Method to show gestures</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkEventBox\" id=\"box_trace\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<child>\n\
<placeholder/>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label10\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Color</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkColorButton\" id=\"button_color\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"color\">#000000000000</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label23\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Width</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">4</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkSpinButton\" id=\"spin_trace_width\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"adjustment\">adjustment_trace_width</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">5</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_feedback\">\n\
<property name=\"label\" translatable=\"yes\">Show popups (</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_left_handed\">\n\
<property name=\"label\" translatable=\"yes\">to the right of the cursor)</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_tray_icon\">\n\
<property name=\"label\" translatable=\"yes\">Show tray icon</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_tray_feedback\">\n\
<property name=\"label\" translatable=\"yes\">Show last gesture in tray</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_autostart\">\n\
<property name=\"label\" translatable=\"yes\">Autostart easystroke</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">&lt;b&gt;Appearance&lt;/b&gt;</property>\n\
<property name=\"use_markup\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkFrame\" id=\"frame1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label_xalign\">0</property>\n\
<property name=\"shadow_type\">none</property>\n\
<child>\n\
<object class=\"GtkAlignment\" id=\"alignment1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"left_padding\">12</property>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<object class=\"GtkTreeView\" id=\"treeview_exceptions\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">&lt;b&gt;Exceptions&lt;/b&gt;</property>\n\
<property name=\"use_markup\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHButtonBox\" id=\"hbuttonbox3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"spacing\">12</property>\n\
<property name=\"layout_style\">start</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_add_exception\">\n\
<property name=\"label\" translatable=\"yes\">_Add Exception</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image4</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_remove_exception\">\n\
<property name=\"label\" translatable=\"yes\">_Remove Exception</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"image\">image7</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_hide2\">\n\
<property name=\"label\" translatable=\"yes\">_Hide</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">2</property>\n\
<property name=\"secondary\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child type=\"tab\">\n\
<object class=\"GtkLabel\" id=\"label2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">Preferences</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"position\">1</property>\n\
<property name=\"tab_fill\">False</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox7\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"border_width\">6</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkFrame\" id=\"frame_advanced1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label_xalign\">0</property>\n\
<property name=\"shadow_type\">none</property>\n\
<child>\n\
<object class=\"GtkAlignment\" id=\"alignment4\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"xalign\">0</property>\n\
<property name=\"xscale\">0</property>\n\
<property name=\"top_padding\">4</property>\n\
<property name=\"bottom_padding\">4</property>\n\
<property name=\"left_padding\">12</property>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox8\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_whitelist\">\n\
<property name=\"label\" translatable=\"yes\">Only enable easystroke for applications listed on 'Actions' tab</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"xalign\">0</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_timeout_gestures\">\n\
<property name=\"label\" translatable=\"yes\">Timeout Gestures</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox1\">\n\
<property name=\"can_focus\">False</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_advanced_ignore\">\n\
<property name=\"label\" translatable=\"yes\">Ignore strokes leading up to advanced gestures</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLinkButton\" id=\"linkbutton1\">\n\
<property name=\"label\" translatable=\"yes\">(See Documentation)</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"has_tooltip\">True</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"relief\">none</property>\n\
<property name=\"uri\">http://easystroke.wiki.sourceforge.net/FeatureAdvancedGestures#content</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox7\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_advanced_popups\">\n\
<property name=\"label\" translatable=\"yes\">Show popups on advanced gestures</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_osd\">\n\
<property name=\"label\" translatable=\"yes\">Show OSD</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHBox\" id=\"hbox6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_scroll_invert\">\n\
<property name=\"label\" translatable=\"yes\">Invert Scroll Direction</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkLabel\" id=\"label8\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Scroll Speed</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHScale\" id=\"hscale1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"adjustment\">adjustment_scroll_speed</property>\n\
<property name=\"value_pos\">right</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"padding\">6</property>\n\
<property name=\"position\">4</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_move_back\">\n\
<property name=\"label\" translatable=\"yes\">Move the cursor back to the original position after each gesture</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">5</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label29\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">&lt;b&gt;Behavior&lt;/b&gt;</property>\n\
<property name=\"use_markup\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkFrame\" id=\"frame_advanced2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label_xalign\">0</property>\n\
<property name=\"shadow_type\">none</property>\n\
<child>\n\
<object class=\"GtkAlignment\" id=\"alignment6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"top_padding\">4</property>\n\
<property name=\"left_padding\">12</property>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkCheckButton\" id=\"check_proximity\">\n\
<property name=\"label\" translatable=\"yes\">Stay in 'scroll' and 'ignore' mode as long as the pen is within range</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">False</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"draw_indicator\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label27\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">&lt;b&gt;Tablet Options&lt;/b&gt;</property>\n\
<property name=\"use_markup\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkFrame\" id=\"frame_advanced3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label_xalign\">0</property>\n\
<property name=\"shadow_type\">none</property>\n\
<child>\n\
<object class=\"GtkAlignment\" id=\"alignment5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"left_padding\">12</property>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow6\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<object class=\"GtkTreeView\" id=\"treeview_devices\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</child>\n\
<child type=\"label\">\n\
<object class=\"GtkLabel\" id=\"label22\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">&lt;b&gt;Devices&lt;/b&gt;</property>\n\
<property name=\"use_markup\">True</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHButtonBox\" id=\"hbuttonbox5\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"spacing\">12</property>\n\
<property name=\"layout_style\">start</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_hide4\">\n\
<property name=\"label\" translatable=\"yes\">_Hide</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
<property name=\"secondary\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"pack_type\">end</property>\n\
<property name=\"position\">4</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"position\">2</property>\n\
</packing>\n\
</child>\n\
<child type=\"tab\">\n\
<object class=\"GtkLabel\" id=\"label21\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"label\" translatable=\"yes\">Advanced</property>\n\
</object>\n\
<packing>\n\
<property name=\"position\">2</property>\n\
<property name=\"tab_fill\">False</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkVBox\" id=\"vbox2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"border_width\">6</property>\n\
<property name=\"spacing\">6</property>\n\
<child>\n\
<object class=\"GtkHPaned\" id=\"hpaned1\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<object class=\"GtkTreeView\" id=\"treeview_recent\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"resize\">True</property>\n\
<property name=\"shrink\">True</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkScrolledWindow\" id=\"scrolledwindow3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"hscrollbar_policy\">automatic</property>\n\
<property name=\"vscrollbar_policy\">automatic</property>\n\
<child>\n\
<object class=\"GtkTreeView\" id=\"treeview_ranking\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
</object>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"resize\">True</property>\n\
<property name=\"shrink\">True</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">True</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">0</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkHButtonBox\" id=\"hbuttonbox2\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"spacing\">12</property>\n\
<property name=\"layout_style\">start</property>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_hide3\">\n\
<property name=\"label\" translatable=\"yes\">_Hide</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">0</property>\n\
<property name=\"secondary\">True</property>\n\
</packing>\n\
</child>\n\
<child>\n\
<object class=\"GtkButton\" id=\"button_matrix\">\n\
<property name=\"label\" translatable=\"yes\">_Matrix</property>\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">True</property>\n\
<property name=\"receives_default\">True</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"use_action_appearance\">False</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">False</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"expand\">False</property>\n\
<property name=\"fill\">True</property>\n\
<property name=\"position\">1</property>\n\
</packing>\n\
</child>\n\
</object>\n\
<packing>\n\
<property name=\"position\">3</property>\n\
</packing>\n\
</child>\n\
<child type=\"tab\">\n\
<object class=\"GtkLabel\" id=\"label3\">\n\
<property name=\"visible\">True</property>\n\
<property name=\"can_focus\">False</property>\n\
<property name=\"events\">GDK_POINTER_MOTION_MASK | GDK_POINTER_MOTION_HINT_MASK | GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK</property>\n\
<property name=\"label\" translatable=\"yes\">_History</property>\n\
<property name=\"use_underline\">True</property>\n\
</object>\n\
<packing>\n\
<property name=\"position\">3</property>\n\
<property name=\"tab_fill\">False</property>\n\
</packing>\n\
</child>\n\
</object>\n\
</child>\n\
</object>\n\
</interface>\n\
";
